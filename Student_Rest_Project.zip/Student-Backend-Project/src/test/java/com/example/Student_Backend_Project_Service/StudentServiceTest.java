
/*package com.example.Student_Backend_Project_Service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.example.Student_Backend_Project_Entity.Student;
import com.example.Student_Backend_Project_Repo.StudentRepository;

@SpringBootTest
class StudentServiceTest {

    @Autowired
    private StudentService studentservice;

    @MockBean
    private StudentRepository studentRepo;

    @BeforeEach
    void setUp() {
        Student student = new Student.Builder()
                .name("Amanda")
                .age("16") 
                .email("amanda34@gmail.com")
                .id(1L)
                .build();

        Mockito.when(studentRepo.getStudentByNameIgnoreCase("Amanda"))
                .thenReturn(student);
    }

    @Test
    @DisplayName("Get By Valid Name")
    public void testGetStudentByName_Valid() {
        String name = "Amanda";
        Student found = studentservice.getStudentByName(name);
        assertEquals(name, found.getName());
    }
}*/
