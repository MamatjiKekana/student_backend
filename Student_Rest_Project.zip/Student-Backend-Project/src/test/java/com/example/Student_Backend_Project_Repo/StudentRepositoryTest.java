/*package com.example.Student_Backend_Project_Repo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import com.example.Student_Backend_Project_Entity.Student;

@DataJpaTest
class StudentRepositoryTest {

	@Autowired
	private StudentRepository studentRepo;
	@Autowired
	private TestEntityManager entitymanager;
	
	@BeforeEach
	void setUp() throws Exception {
		Student student= new Student.Builder()
				.name("Mercy")
				.age("16")
				.email("Mercy@gmail.com")
				.build();
		entitymanager.persist(student);
	}

	@Test
	public void testFindById() {
		Student student=studentRepo.findById(1L).get();
		assertEquals(student.getName(),"mercy");
	}

}*/
