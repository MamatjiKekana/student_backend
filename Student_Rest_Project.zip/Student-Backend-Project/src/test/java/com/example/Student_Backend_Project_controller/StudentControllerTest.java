/*package com.example.Student_Backend_Project_controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.example.Student_Backend_Project_Entity.Student;
import com.example.Student_Backend_Project_Service.StudentService;

@WebMvcTest(StudentController.class)
class StudentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private StudentService studentservice;

    private Student student;

    @BeforeEach
    void setUp() throws Exception {
        student = new Student.Builder()
                .name("Amanda")
                .age("16")
                .email("amanda34@gmail.com")
                .id(1L)
                .build();
    }

    @Test
    void testSaveStudent() throws Exception {
        Student inputStudent = new Student.Builder()
                .name("Amanda")
                .age("16")
                .email("amanda34@gmail.com")
                .id(2L)
                .build();

        Mockito.when(studentservice.saveStudent(inputStudent)).thenReturn(student);

        mockMvc.perform(MockMvcRequestBuilders
                .post("/students")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Amanda\",\"age\":\"16\",\"email\":\"amanda34@gmail.com\",\"id\":2}"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetStudentById() throws Exception {
        Mockito.when(studentservice.getStudentById(1L)).thenReturn(student);

        mockMvc.perform(MockMvcRequestBuilders
                .get("/students/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value(student.getName()))
                .andExpect(jsonPath("$.age").value(student.getAge()))
                .andExpect(jsonPath("$.email").value(student.getEmail()));
    }
}
*/
