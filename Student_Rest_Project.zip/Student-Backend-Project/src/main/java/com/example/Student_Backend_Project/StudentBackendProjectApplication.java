package com.example.Student_Backend_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentBackendProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentBackendProjectApplication.class, args);
	}

}
