package com.example.Student_Backend_Project_Service;

import java.util.List;
import java.util.Optional;

import com.example.Student_Backend_Project_Entity.Student;

public interface StudentService {

	public List<Student> getStudents();

	public Optional<Student> getStudentById(Long id);

	public Student saveStudent(Student student);

	public Student updateStudent(Student student, Long id);

	public void deleteStudent(Long id);

	public Student getStudentByName(String name);

	

}
