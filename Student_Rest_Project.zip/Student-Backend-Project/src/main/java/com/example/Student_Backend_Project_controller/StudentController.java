package com.example.Student_Backend_Project_controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*; 
import com.example.Student_Backend_Project_Entity.Student;
import com.example.Student_Backend_Project_Service.StudentService;

@RestController
@RequestMapping("/students") 
public class StudentController {

    @Autowired
    private StudentService studentservice;
    private final Logger LOGGER=LoggerFactory.getLogger(StudentController.class);

    @GetMapping("/students")
    public List<Student> getStudents() { 
        return studentservice.getStudents();
    }

    @GetMapping("/{id}")
    public Optional<Student> getStudentById(@PathVariable("id") Long id) {
    	LOGGER.info("Inside  getStudentById in StudentController");
        return studentservice.getStudentById(id);
    }
    @GetMapping("/students/name/{name}")
    public Student getStudentByName(@PathVariable String name) {
		return studentservice.getStudentByName(name);
    	
    }

    @PostMapping("/students")
    public Student saveStudent(@RequestBody Student student) { 
    	LOGGER.info("Inside  saveStudent in StudentController");
        return studentservice.saveStudent(student);
    }

    @PutMapping("/students/{id}") 
    public Student updateStudent(@RequestBody Student student, @PathVariable Long id) {
        return studentservice.updateStudent(student, id); 
    }

    @DeleteMapping("/{id}") 
    public void deleteStudent(@PathVariable Long id) {
    	LOGGER.info("Inside  deleteStudent in StudentController");
        studentservice.deleteStudent(id);
    }
}
