package com.example.Student_Backend_Project_Service_imp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Student_Backend_Project_Entity.Student;
import com.example.Student_Backend_Project_Repo.StudentRepository;
import com.example.Student_Backend_Project_Service.StudentService;

@Service
public class StudentServiceImp implements StudentService {

    @Autowired
    private StudentRepository studentRepo;

    @Override
    public List<Student> getStudents() {
        return studentRepo.findAll();
    }

    @Override
    public Optional<Student> getStudentById(Long id) {
        return  studentRepo.findById(id);
        
    }

    @Override
    public Student saveStudent(Student student) {
        return studentRepo.save(student);
    }

    @Override
    public Student updateStudent(Student student, Long id) {
        // Check if the student exists
        Optional<Student> existingStudent = studentRepo.findById(id);
        if (existingStudent.isPresent()) {
            Student updatedStudent = existingStudent.get();
            // Update the fields as needed
            updatedStudent.setName(student.getName());
            updatedStudent.setAge(student.getAge());
            updatedStudent.setEmail(student.getEmail());
            // Save the updated entity
            return studentRepo.save(updatedStudent);
        } else {
            throw new RuntimeException("Student with ID " + id + " not found.");
        }
    }

    @Override
    public void deleteStudent(Long id) {
        if (studentRepo.existsById(id)) {
            studentRepo.deleteById(id);
        } else {
            throw new RuntimeException("Student with ID " + id + " not found.");
        }
    }

	@Override
	public Student getStudentByName(String name) {
		return  studentRepo.getStudentByNameIgnoreCase( name);
		
	}
}

